package com.gndec.timetable.ui.syllabus

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gndec.timetable.ui.motion.LocalReducedMotion
import com.gndec.timetable.ui.motion.Motion
import com.gndec.timetable.ui.motion.motionTween
import kotlin.math.roundToInt

// Reveal cadence for streamed text. Fast enough to read as continuous writing, slow enough
// that the markdown re-render behind it stays well inside a frame budget.
private const val CHARS_PER_SECOND = 110f
private const val MAX_STEP_SECONDS = 0.08f
private const val MIN_CHARS_PER_STEP = 1

// Past this backlog a per-character reveal is invisible anyway — the reader is already
// behind the text — so jumping straight to the new text is both cheaper and indistinguishable.
private const val CATCH_UP_CHARS = 320

// While the model is still reasoning only the tail is shown, so a five-minute thought
// cannot push the answer off screen before the student has seen any of it.
private const val REASONING_PREVIEW_CHARS = 520

/**
 * Streams text in at a steady reading pace instead of snapping to whatever the network
 * just delivered.
 *
 * The coroutine is keyed on *whether* it should animate, never on the text itself, so a
 * burst of tokens does not restart the animation: new characters simply extend the
 * revealed prefix on the next frame. Only this composable's state is written, so a
 * streaming answer never recomposes the message list around it, and once streaming ends
 * the text settles onto its final value with no further frames.
 */
@Composable
fun rememberStreamedText(target: String, streaming: Boolean): State<String> {
    val latest = rememberUpdatedState(target)
    // Seeded with the text already in hand, so a composition recreated mid-stream (rotation,
    // navigation) picks up where the stream is rather than replaying it from the first token.
    val revealed: MutableState<String> = remember { mutableStateOf(target) }
    val animating = streaming && !LocalReducedMotion.current

    LaunchedEffect(animating) {
        if (!animating) {
            // Settled: cancellation, error, or a finished message. Jump to the final text
            // rather than leaving a half-revealed tail on screen.
            revealed.value = latest.value
            return@LaunchedEffect
        }
        var previousFrame = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val elapsed = ((now - previousFrame) / 1_000_000_000f).coerceIn(0f, MAX_STEP_SECONDS)
            previousFrame = now

            val current = latest.value
            val shown = revealed.value
            if (current == shown) continue
            val pending = current.length - shown.length
            if (pending <= 0) {
                // The stream restarted or shrank: follow it exactly rather than animating
                // backwards through text that is being replaced.
                revealed.value = current
                continue
            }
            if (pending > CATCH_UP_CHARS) {
                revealed.value = current
                continue
            }
            val step = (CHARS_PER_SECOND * elapsed).roundToInt().coerceAtLeast(MIN_CHARS_PER_STEP)
            val end = (shown.length + step).coerceAtMost(current.length)
            // Reuse the incoming instance when the whole backlog clears, so a caught-up
            // reader does not re-copy the string on every frame.
            revealed.value = if (end == current.length) current else current.substring(0, end)
        }
    }
    return revealed
}

/**
 * An assistant turn: optional reasoning, folded away by default, above the answer.
 *
 * Both halves are rendered identically whether the turn is still streaming or already
 * persisted, so the swap from live bubble to saved message is invisible.
 */
@Composable
fun AssistantReply(
    reasoning: String,
    answer: String,
    streaming: Boolean,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
        Text(
            "GNDEC syllabus assistant",
            color = MaterialTheme.colorScheme.primary,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(5.dp))
        if (reasoning.isNotBlank()) {
            // Reasoning is "live" only until the first answer token arrives; from then on the
            // block settles, folds itself away, and stops consuming frames.
            ReasoningBlock(reasoning = reasoning, live = streaming && answer.isBlank())
            Spacer(Modifier.height(10.dp))
        }
        val revealedAnswer by rememberStreamedText(answer, streaming = streaming)
        if (revealedAnswer.isNotBlank()) RichMarkdownText(revealedAnswer)
    }
}

/**
 * Model reasoning, kept visually subordinate to the answer: grey, quiet, and collapsed
 * into a single line once the model moves on to the answer.
 */
@Composable
private fun ReasoningBlock(reasoning: String, live: Boolean) {
    var expanded by rememberSaveable { mutableStateOf(true) }
    // Open while the model is still thinking so the student sees progress; folded away as
    // soon as the answer starts so it never competes with it. A tap overrides either way.
    LaunchedEffect(live) { if (!live) expanded = false }

    val revealed by rememberStreamedText(reasoning, streaming = live)
    val label = if (live) "Thinking…" else "Reasoning"
    val body = if (live) tailPreview(revealed, REASONING_PREVIEW_CHARS) else revealed

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.32f))
            .animateContentSize(animationSpec = motionTween(Motion.Normal))
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .clickable { expanded = !expanded }
                .padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (live) {
                CircularProgressIndicator(
                    Modifier.size(13.dp),
                    strokeWidth = 1.6.dp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Icon(
                    Icons.Default.Psychology,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(15.dp)
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(
                label,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
            Icon(
                if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = if (expanded) "Hide reasoning" else "Show reasoning",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(17.dp)
            )
        }
        if (expanded && body.isNotBlank()) {
            Spacer(Modifier.height(2.dp))
            Text(
                body,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp),
                modifier = Modifier.padding(start = 10.dp, end = 10.dp, top = 2.dp, bottom = 10.dp)
            )
        }
    }
}

/** Most recent [maxChars] characters, marked so it reads as a continuation. */
internal fun tailPreview(text: String, maxChars: Int): String =
    if (text.length <= maxChars) text else "…" + text.takeLast(maxChars)
